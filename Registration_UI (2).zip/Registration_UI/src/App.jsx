import { ChakraProvider } from "@chakra-ui/react";
import { BrowserRouter } from "react-router-dom";
import AppRoutes from "./routes/AppRoutes";
import { AuthProvider } from "./context/AuthContext";
import { DealProvider } from "./context/DealContext";
import Navbar from "./components/layout/Navbar";
import theme from "./theme";

function App() {
  return (
    <ChakraProvider theme={theme}>
      <BrowserRouter>
        <AuthProvider>
          <DealProvider>
            {/* Navbar stays fixed on top */}
            <Navbar />

            {/* App content — PageWrapper handles layout */}
            <AppRoutes />
          </DealProvider>
        </AuthProvider>
      </BrowserRouter>
    </ChakraProvider>
  );
}

export default App;
